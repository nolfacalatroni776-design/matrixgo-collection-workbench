#!/usr/bin/env python3
import argparse,threading,secrets,os,time,json,hashlib,sys,webbrowser,shutil
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit
from model import prepare,must,CAT,integer,question_csv
import engine
ROOT=Path(__file__).resolve().parent
STATE=Path(os.environ.get('MATRIX_WIZARD_STATE',str(ROOT/'.local-state-personal')));STATE.mkdir(exist_ok=True,parents=True,mode=0o700)
approval_links={};TOKEN=secrets.token_urlsafe(32);plans={};lock=threading.Lock();busy=False

DEFAULT_ENV='PROD'
import subprocess
login_lock=threading.Lock();logins={}
def auth(start=False):
 env=engine.ENV.get()
 with login_lock:
  try:
   child=logins.get(env);pending=child is not None and child.poll() is None
   if pending:state='等待授权'
   else:
    status=subprocess.run(engine.invocation(['auth','status']),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=12).returncode
    state='已授权' if status==0 else ('授权未完成' if child else '需本人登录') if status==3 else '检查失败'
    if start and status==3:
     must(not any(t.poll() is None for t in logins.values()),'另一个环境正在等待本人授权，请先完成授权。')
     logins[env]=subprocess.Popen([engine.BIN,'--base-url',engine.HOSTS[env],'auth','login'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);state='等待授权'
  except (FileNotFoundError,subprocess.TimeoutExpired):state='CLI 不可用'
 return {'name':env,'platform':engine.HOSTS[env],'state':state}
def receipt(data):
 p=STATE/(data['id']+'.json');tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False));os.replace(tmp,p)
def worker(c,s,r):
 global busy
 engine.ENV.set(s['environment'])
 def log(msg):
  if msg.startswith('APPROVAL_LINK '):approval_links[r['id']]=msg.split(' ',1)[1];return
  r['log'].append(time.strftime('%H:%M:%S')+'  '+msg);receipt(r)
 try:engine.run(c,s,log);r['state']='done'
 except Exception as e:r['state']='stopped';log('已停止：'+str(e)+'。已成功的步骤不会自动撤销。请先在平台核对，再处理剩余步骤；不要直接重传。')
 finally:
  approval_links.pop(r['id'],None);receipt(r)
  with lock:busy=False

def validate(c):
 result=prepare(c);j=c['job'];
 if c['target']=='new':
  for key,hi in [('timeout',999999),('nodeLimit',999999),('workerLimit',5000)]:
   v=j.get(key);must(v is None or (key!='workerLimit' and v==-1) or integer(v,1,hi),'节点数量或时限填写不正确：'+key)
  must(j.get('timeoutAction','DELETE') in ['DELETE','SUBMIT'],'超时处理错误')
 return result
class H(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def send(self,n,data,ct='application/json; charset=utf-8'):
  body=data.encode() if isinstance(data,str) else json.dumps(data,ensure_ascii=False).encode();self.send_response(n);self.send_header('Content-Type',ct);self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'");self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def safe(self):return self.headers.get('Host')==self.server.addr
 def readiness(self,options=False):
  origin='https://nolfacalatroni776-design.github.io'
  if not self.safe() or self.headers.get('Origin')!=origin:return self.send(403,{'error':'来源无效'})
  body=b'' if options else b'{"service":"matrixgo-personal-workbench"}'
  self.send_response(204 if options else 200);self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin');self.send_header('Cache-Control','no-store');self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)))
  if options:self.send_header('Access-Control-Allow-Methods','GET');self.send_header('Access-Control-Allow-Private-Network','true')
  self.end_headers();self.wfile.write(body)
 def do_OPTIONS(self):
  if self.path=='/workbench-ready' and self.headers.get('Access-Control-Request-Method')=='GET':return self.readiness(True)
  return self.send(403,{'error':'不支持此请求'})
 def do_GET(self):
  if not self.safe():return self.send(403,{'error':'使用本机 127.0.0.1 地址'})
  env=self.headers.get('X-Matrix-Env',DEFAULT_ENV)
  if env not in engine.HOSTS:return self.send(400,{'error':'环境无效'})
  engine.ENV.set(env);p=urlsplit(self.path).path
  if p in ['/guide/collection','/guide/collection.js']:
   doc=(ROOT.parent/'题目与采集数据_双轨动画.html').read_text();head,tail=doc.split('<script>',1);script,foot=tail.split('</script>',1)
   if p.endswith('.js'):return self.send(200,script,'text/javascript; charset=utf-8')
   return self.send(200,head+'<script src="/guide/collection.js"></script>'+foot,'text/html; charset=utf-8')
  if p=='/':return self.send(200,(ROOT/'index.html').read_text().replace('__SESSION__',TOKEN),'text/html; charset=utf-8')
  if p in ['/ui.js','/csv-lens.js','/ui.css']:return self.send(200,(ROOT/p[1:]).read_text(),'text/javascript; charset=utf-8' if p.endswith('.js') else 'text/css; charset=utf-8')
  if p in ('/examples/a182-static','/examples/a182-dynamic'):
   file=ROOT.parent/'A182采集联测'/('静态配置.json' if p.endswith('static') else '动态配置.json');return self.send(200,file.read_text()) if file.is_file() else self.send(404,{'error':'未找到联测草稿'})
  if p=='/workbench-ready':return self.readiness()
  if p=='/environment':return self.send(200,auth())
  if p=='/catalog':return self.send(200,CAT)
  if p=='/history':
   items=[]
   for f in sorted(STATE.glob('*.json'),key=lambda x:x.stat().st_mtime,reverse=True)[:20]:
    v=json.loads(f.read_text());
    if v.get('environment',DEFAULT_ENV)!=env:continue
    if v['id'] in approval_links:v['approvalLink']=approval_links[v['id']]
    items.append(v)
   return self.send(200,items)
  return self.send(404,{'error':'页面不存在'})
 def do_POST(self):
  global busy
  try:
   must(self.safe() and self.headers.get('Origin')=='http://'+self.server.addr and secrets.compare_digest(self.headers.get('X-Local-Session',''),TOKEN),'本机页面会话已过期，请刷新');length=int(self.headers.get('Content-Length','0'));must(0<length<=4_000_000,'配置文件过大');d=json.loads(self.rfile.read(length));p=self.path
   env=self.headers.get('X-Matrix-Env',DEFAULT_ENV);must(env in engine.HOSTS,'环境无效');engine.ENV.set(env)
   if p=='/login':return self.send(200,auth(start=True))
   if p=='/question-csv':return self.send(200,question_csv(d))
   if p=='/theme-plan':
    c={**d['config'],'action':'generate'};must(c['mode']=='DYNAMIC','仅适用于动态题库');prepare(c,data_only=True);b=c['batch'];return self.send(200,{'totalQuantity':b['copies'],'skipQuantity':b['skip'],'rules':b['rules']})
   if p=='/flows':return self.send(200,engine.find_flows(d['project'],d.get('projectId')))
   if p in ['/preview','/check']:
    # The web wizard always ends after upload and readback, including legacy drafts.
    c={**d['config'],'action':'import'};csv,w=prepare(c,data_only=True) if p=='/preview' else validate(c);result={'csv':csv,'warnings':w,'steps':engine.description(c)}
    if p=='/check':
     s=engine.lookup(c);i=secrets.token_hex(16)
     with lock:
      for k in list(plans):
       if plans[k][2]<time.time():plans.pop(k)
      plans[i]=(c,s,time.time()+600)
     result.update(ticket=i,target=s)
    return self.send(200,result)
   if p=='/execute':
    with lock:
     must(not busy,'另一个执行正在进行');ticket=d.get('ticket','');v=plans.get(ticket);must(v and v[2]>time.time(),'核对已过期或已经执行，请重新核对');c,s,_=v;must(s['environment']==env,'核对的环境已变更');must(d.get('accept')==c['project'],'请输入项目编号确认');plans.pop(ticket);i=secrets.token_hex(8);r={'id':i,'environment':env,'project':c['project'],'name':s.get('flow',c['name']),'state':'running','created':time.strftime('%Y-%m-%d %H:%M'),'log':[]};receipt(r);busy=True
    threading.Thread(target=worker,args=(c,s,r),daemon=False).start();return self.send(200,{'id':i})
   return self.send(404,{'error':'接口不存在'})
  except Exception as e:return self.send(400,{'error':str(e) or '请求失败'})
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--port',type=int,default=18767);a.add_argument('--open',action='store_true');opt=a.parse_args();srv=ThreadingHTTPServer(('127.0.0.1',opt.port),H);srv.addr='127.0.0.1:'+str(srv.server_port);url='http://'+srv.addr+'/'
 for path in STATE.glob('*.json'):
  old=json.loads(path.read_text());
  if old.get('state')=='running':old['state']='interrupted';old['log'].append('本机服务中断；请先查询平台，核实已完成步骤。');receipt(old)
 print(url,flush=True)
 if opt.open:webbrowser.open(url)
 srv.serve_forever()

#!/bin/sh
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin:$PATH" PYTHONUTF8=1
if /usr/bin/curl --noproxy '*' -fsS --max-time 2 -H 'Origin: https://nolfacalatroni776-design.github.io' http://127.0.0.1:18767/workbench-ready 2>/dev/null | /usr/bin/grep -q 'matrixgo-personal-workbench'; then
 /usr/bin/open 'http://127.0.0.1:18767/'; exit 0
fi
if ! command -v python3 >/dev/null || ! python3 -c 'import sys;sys.exit(sys.version_info < (3,9))' 2>/dev/null; then
 echo '本机配置台需要 Python 3.9 或以上版本。可以请 IT 安装，或回到网页使用「下载 CSV」。'; exit 1
fi
export MATRIX_WIZARD_STATE="$HOME/Library/Application Support/MatrixGo Collection Workbench/receipts"
echo '正在打开采集配置台，不需要输入命令。使用期间请保持此窗口打开。'
exec python3 -B runner/app.py --open

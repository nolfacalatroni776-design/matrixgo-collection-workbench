#!/bin/sh
cd "$(dirname "$0")" || exit 1
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH" PYTHONUTF8=1
exec python3 runner/app.py --open

import os,json,re,tempfile,shutil,subprocess,hashlib,time
from pathlib import Path
from collections import defaultdict,Counter
from model import must,prepare
DEV='https://ui.appen.com.cn'
BIN=shutil.which('matrix-go') or str(Path(os.getenv('LOCALAPPDATA',''))/'matrix-go'/'matrix-go.exe' if os.name=='nt' else Path.home()/'.local/bin/matrix-go')
def invocation(args):return [BIN,'--base-url',DEV,*args,'--json']
def cli(args,confirm=False,notice=lambda x:None):
 def call(a,timeout):
  try:return subprocess.run(invocation(a),capture_output=True,encoding='utf8',timeout=timeout,stdin=subprocess.DEVNULL)
  except FileNotFoundError:raise ValueError('未找到 matrix-go。请先安装并在终端执行 matrix-go auth login。')
 r=call(args,150)
 if r.returncode==4 and confirm:
  raw=r.stderr;code=re.search(r'--confirm\s+([A-Za-z0-9-]+)',raw);must(code,'CLI 要求网页确认，但未能识别确认单。请检查平台状态。');link=re.search(r'https://[^\s]+/agent-confirm\?[^\s]+',raw)
  if link:notice('APPROVAL_LINK '+link[0]);
  notice('等待本人在 MatrixGo 打开的网页确认生成。拒绝或过期时将停止。');r=call([*args,'--confirm',code[1]],640)
 if r.returncode:raise ValueError(re.sub(r'https?://\S+','[平台链接]',(r.stderr or r.stdout or 'CLI 操作失败'))[:950])
 return json.loads(r.stdout or 'null')
def pages(prefix):
 out=[]
 for i in range(10000):
  d=cli([*prefix,'--page-index',str(i),'--page-size','100']);out.extend(d['results']);
  if len(out)>=d['totalElements'] or not d['results']:return out
 raise ValueError('分页数量过大')
def find_flows(project,pinned_id=None):
 must(isinstance(project,str) and re.fullmatch(r'A\d+',project),'请先填写项目编号');d=cli(['project','list','--project-display-id',project]);p=next((x for x in d['results'] if x['projectDisplayId']==project),None);must(p,'线上未找到可访问的项目 '+project);must(not pinned_id or p['id']==pinned_id,'项目 ID 与所选链接不一致');rows=pages(['collect','flow','list','--project-id',p['id']]);return [{'flow':x['flowDisplayId'],'name':x['flowName'],'mode':x.get('scriptType'),'status':x.get('status'),'test':x.get('testFlag')} for x in rows]
def lookup(c):
 d=cli(['project','list','--project-display-id',c['project']]);p=next((x for x in d['results'] if x['projectDisplayId']==c['project']),None);must(p,'在线上环境没有找到可访问的项目 '+c['project']);pid=p['id'];must(not c.get('projectId') or c['projectId']==pid,'目标项目 ID 与草稿绑定的项目不一致');P=['--project-id',pid];must(p['projectStatus']=='RUNNING','项目已结束');must(p['agentAccess']=='ALL','项目 Agent 权限不是 ALL，请项目拥有者在平台调整后再执行。');detail=cli(['project','get',*P]);must(detail.get('memberStatus') in ['UPDATE','ADMIN'],'当前账号没有项目编辑权限');base={'environment':'PROD','platform':DEV,'project':p['projectDisplayId'],'projectName':p['name'],'pid':pid,'access':p['agentAccess']};new=c['target']=='new';l=pages(['collect','flow','list',*P,*(['--flow-name',c['name']] if new else ['--flow-display-id',c['flow']])]);
 if new:must(not any(x['flowName']==c['name'] for x in l),'项目已有同名工作流，请另取名称或选择已有流程');return base
 f=next((x for x in l if x['flowDisplayId']==c['flow']),None);must(f,'未找到指定流程');fid=f['id'];F=[*P,'--flow-id',fid];detail=cli(['collect','flow','get',*F]);must(detail['status']=='RUNNING' and detail['scriptType']==c['mode'],'流程已停用或数据类型不一致');job=next((x for x in detail['jobs'] if x['jobType']=='DATA_COLLECT'),None);must(job,'未找到采集节点');j=cli(['collect','job','get',*P,'--job-id',job['id']]);must(j['jobStatus'] in ['READY','RUNNING','PAUSE'],'节点状态不支持此次操作');must(c['action']!='publish' or j['jobStatus']=='READY' and j['groupType']!='SELF_CROWD','仅可发布待发布且非自营的采集节点');must('GUI' not in (j.get('businessTags') or []) or all(x['type']=='GUI' for x in c['questions']),'此节点只接受 GUI 题');
 if j['acquirePattern']=='BY_PIN':
  pins={};[pins.setdefault(x['group'],x.get('pin','')) for x in c['questions']];must(all(pins.values()),'节点凭 PIN 领取，各脚本首行必填 PIN');
 base.update(fid=fid,flow=detail['flowDisplayId'],flowName=detail['flowName'],jid=j['id'],job=j['jobDisplayId'],status=j['jobStatus'],team=j.get('groupType'),payment=j.get('paymentType'),rate=j.get('paymentRate'),categoryRates=j.get('categoryRates'),overseas=j.get('rowFlag'),acquire=j.get('acquirePattern'))
 st=c['mode']=='STATIC';old=pages(['collect','script' if st else 'prompt','list',*F]);keys={x['name'] for x in old};newkeys={x['group' if st else 'name'] for x in c['questions']};must(not keys&newkeys,'目标中已存在同名脚本或题目：'+', '.join(sorted(keys&newkeys)[:6]));
 if st:must(not({x.get('pin') for x in old if x.get('pin')}&{x.get('pin') for x in c['questions'] if x.get('pin')}),'PIN 已被已有脚本使用');
 if not st and c['action']!='import':
  affected=[r for r in old if r.get('themeName') in {x['theme'] for x in c['batch']['rules']} and r.get('status')=='ACQUIRABLE'];base['existingCandidates']=len(affected)
 return base

def description(c):
 st=c['mode']=='STATIC';steps=['定位项目并复核权限、目标与重名情况'];
 if c['target']=='new':steps+=['创建采集工作流','创建待发布采集节点']
 steps+=['导入静态脚本 CSV' if st else '向动态题库追加 CSV','从平台回查分组、题型、题面、属性和输入项'];
 if not st and c['action']!='import':steps+=['按主题生成任务（本人网页确认）','等待异步生成并回查份数'];
 if c['action']=='publish':steps+=['发布采集节点，符合条件的采集员可以领取，可能产生费用'];return steps
 return steps

def run(c,snapshot,log):
 csvdata,_=prepare(c);must(lookup(c)==snapshot,'目标状态与预览不一致，请重新核对');p=snapshot['pid'];P=['--project-id',p];st=c['mode']=='STATIC';new=c['target']=='new';j=c['job'];b=c['batch'];qs=c['questions'];
 def act(name,args,appr=False):log('正在'+name);return cli(args,appr,log)
 if new:
  f=act('创建流程',['collect','flow','create',*P,'--flow-name',c['name'],'--flow-category',c['category'],'--test-flag='+str(c['test']).lower()]);fid=f['id'];log('已创建 '+f['flowDisplayId']);F=[*P,'--flow-id',fid];chk=cli(['collect','flow','get',*F]);must(chk['status']=='RUNNING' and not chk['jobs'],'新流程状态或节点已变化');args=['collect','job','create',*F,'--job-type','DATA_COLLECT','--job-name',j['name'],'--script-type',c['mode'],'--group-type',j['team'],'--description',j['desc']];
  if j['team']=='SELF_CROWD':args+=['--demand-id',j['demand']]
  else:
   args+=['--acquire-pattern',j['acquire'],'--contact-email',j['email'],'--payment-type',j['payment']];args+=['--body',json.dumps({'categoryRates':j['rates']})] if j['payment']=='BY_QUESTION_TYPE' else ['--payment-rate',str(j['rate'])];
   if j['team']=='BPO_COMPANY':args+=['--bpo-id',j['bpo']]
   if j['team']=='PUBLIC':args+=['--row-flag='+str(j['overseas']).lower()]
  if j.get('gui'):args+=['--business-tags','GUI']
  for k,flag in [('timeout','--timeout-minutes'),('nodeLimit','--limit-quantity'),('workerLimit','--worker-limit')]:
   if j.get(k) is not None and (k!='workerLimit' or j['team']=='PUBLIC'):args += [flag,str(j[k])]
  if j.get('timeout') not in (None,-1):args+=['--timeout-transfer-type',j['timeoutAction']]
  job=act('创建采集节点',args);jid=job['id'];log('已创建 '+job['jobDisplayId'])
 else:fid=snapshot['fid'];jid=snapshot['jid'];F=[*P,'--flow-id',fid]
 chk=cli(['collect','flow','get',*F]);must(chk['scriptType']==c['mode'] and chk['status']=='RUNNING','节点类型或流程状态不符');status=next(x['jobStatus'] for x in chk['jobs'] if x['id']==jid);must(status==('READY' if new else snapshot['status']),'上传前节点状态变化，请重新核对');
 with tempfile.TemporaryDirectory() as td:
  path=Path(td)/'collection.csv';path.write_bytes(csvdata.encode());args=['collect','script' if st else 'prompt','upload',*F,'--file',str(path)];
  if st:args+=['--total-quantity',str(b['total']),'--skip-quantity',str(b['skip']),'--limit-quantity',str(b['limit'])]
  act('上传 CSV',args)
 log('CSV 已受理，正在逐题回查');groups=defaultdict(list)
 for q in qs:groups[q['group']].append(q)
 def obj(x,default):return json.loads(x) if isinstance(x,str) and x else default if x is None or x=='' else x
 def verify(r,q):
  must((r['name'],r['promptType'],r.get('content'),obj(r.get('attributes'),{}),obj(r.get('inputs'),[]))==(q['name'],q['type'],q['content'],q['attrs'],q['inputs']),'回查不一致：'+q['name'])
 if st:
  scripts=pages(['collect','script','list',*F]);byname={x['name']:x for x in scripts};
  for g,items in groups.items():
   sc=byname.get(g,{});must((sc.get('totalQuantity'),sc.get('skipQuantity'),sc.get('limitQuantity'))==(b['total'],b['skip'],b['limit']),'脚本未找到或额度不符：'+g);rr=sorted(pages(['collect','prompt','list',*F,'--script-id',sc['id']]),key=lambda v:v['sequence']);must(len(rr)==len(items),'脚本题数不一致');
   for x,q in zip(rr,items):verify(x,q)
 else:
  rows=pages(['collect','prompt','list',*F]);nm=defaultdict(list)
  for x in rows:nm[x['name']].append(x)
  for q in qs:
   ar=nm[q['name']];must(len(ar)==1,'题目未找到或名称重复：'+q['name']);x=ar[0];verify(x,q);must(x['themeName']==q['group'] and x['totalQuantity']==q['total'] and x['priority']==q['priority'] and (q['limit'] is None or x.get('limitQuantity')==q['limit']),'动态题目分组或额度不一致')
 log(f'回查一致：{len(groups)} 个分组，{len(qs)} 道题。');
 if not st and c['action']!='import':
  cli(['collect','script','get',*F]);r=act('发起动态生成',['collect','script','generate',*F,'--total-quantity',str(b['copies']),'--skip-quantity',str(b['skip']),'--body',json.dumps({'rules':b['rules']},ensure_ascii=False)],True);log('已受理生成 '+r['taskId']);cli(['task','wait',r['taskId'],*P,'--timeout','2m']);sc=cli(['collect','script','get',*F]);must(sc.get('generateQuantity')==b['copies'] and sc.get('generateStatus')=='END','生成数量或状态尚未验证，不继续发布');log('实际已生成 '+str(b['copies'])+' 份')
 if c['action']=='publish':
  J=[*P,'--job-id',jid];must(cli(['collect','job','get',*J])['jobStatus']=='READY','节点不在待发布状态，停止发布');act('发布节点',['collect','job','start',*J]);must(cli(['collect','job','get',*J])['jobStatus']=='RUNNING','发布后状态尚未确认');log('已回查：节点进行中。')
 log('完成：'+chk['flowDisplayId'])

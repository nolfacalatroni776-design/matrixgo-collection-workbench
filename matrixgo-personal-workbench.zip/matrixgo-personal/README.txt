需要 Python 3.9+ 和 MatrixGo CLI。启动配置台，选择线上或 DEV，再点击一键登录并用本人账号授权。Mac 也可执行 sh start.command；Windows 运行 start.cmd。服务仅在本机 127.0.0.1:18767 监听；关闭终端即可停止。

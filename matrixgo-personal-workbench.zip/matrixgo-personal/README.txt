需要 Python 3.9+ 和 MatrixGo CLI。请在自己的终端执行 matrix-go --base-url https://ui.appen.com.cn auth login，然后启动配置台。Mac 也可执行 sh start.command；Windows 运行 start.cmd。服务仅在本机 127.0.0.1:18767 监听；关闭终端即可停止。

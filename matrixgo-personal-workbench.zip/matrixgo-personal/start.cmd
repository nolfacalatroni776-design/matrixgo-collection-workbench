@echo off
cd /d "%~dp0"
set PYTHONUTF8=1
where py >nul 2>nul && (py -3 runner/app.py --open & pause & exit /b)
python runner/app.py --open
pause
